"""Official Python SDK for the Sonco Pay crypto payment API.

>>> from soncopay import SoncoPay
>>> sp = SoncoPay("sp_test_...")
>>> payment = sp.payments.create(amount="25", currency="USD", order_id="demo-1042")
>>> payment["checkout_url"]
"""
from . import webhooks
from ._client import (DEFAULT_BASE_URL, Billing, Customers, Invoices, Ledger, Payments, PayoutDestinations, Payouts,
                      Plans, Refunds, Settlement, SoncoPay, Statements, Subscriptions)
from ._errors import (
    ApiConnectionError,
    ApiError,
    ApiTimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    SignatureVerificationError,
    SoncoPayError,
    ValidationError,
)
from ._version import __version__
from .webhooks import WebhookEvent, construct_event, verify

__all__ = [
    "__version__",
    "DEFAULT_BASE_URL",
    "SoncoPay",
    "Payments",
    "Payouts",
    "Ledger",
    "PayoutDestinations",
    "Statements",
    "Settlement",
    "Customers",
    "Plans",
    "Invoices",
    "Subscriptions",
    "Billing",
    "Refunds",
    "webhooks",
    "WebhookEvent",
    "construct_event",
    "verify",
    "SoncoPayError",
    "ApiError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "ApiConnectionError",
    "ApiTimeoutError",
    "SignatureVerificationError",
]
