"""Webhook verification.

Sonco Pay POSTs a JSON body ``{"event", "created_at", "data"}`` with these headers:

* ``X-SoncoPay-Event``: ``payment.confirming``, ``payment.paid``, ``payment.expired``, ``payment.settled``,
  ``payout.sent``, ``payout.completed``, ``payout.failed``, ``payout_destination.created``,
  ``payout_destination.confirmed``, ``payout_destination.usable``, ``payout_destination.removed``,
  ``payment.settlement_held`` (2.9.0), ``payment.refunded``, ``refund.*`` (``refund.created``,
  ``refund.scheduled``, ``refund.sent``, ``refund.completed``, ``refund.failed``, ``refund.cancelled``...) or ``ping``;
* ``X-SoncoPay-Delivery-Id``: stable id of the delivery (the same on every retry: ignore a delivery you already
  processed);
* ``X-SoncoPay-Timestamp``: Unix time of this attempt;
* timestamped signature (2.5.0) ``t=<timestamp>,v1=<hex HMAC-SHA256(secret, "<timestamp>." + raw body)>``, refused
  outside a 5 minute window (replay protection);
* legacy signature: hex HMAC-SHA512 of the RAW body (no timestamp).

Which header carries which format depends on the "Signature format" of your account (dashboard, Developers >
Webhook): "timestamped" puts the new format in ``X-SoncoPay-Signature`` (legacy one in ``X-SoncoPay-Signature-Legacy``),
"legacy" keeps the old format in ``X-SoncoPay-Signature`` (new one in ``X-SoncoPay-Signature-V2``). Pass the whole
headers mapping to :func:`verify` / :func:`construct_event`: the timestamped signature is checked whenever it is
present, wherever it is, and the legacy one is only used when no timestamped signature was sent.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Optional, Union

from ._errors import SignatureVerificationError

__all__ = ["SIGNATURE_HEADER", "SIGNATURE_V2_HEADER", "SIGNATURE_LEGACY_HEADER", "TIMESTAMP_HEADER",
           "DELIVERY_ID_HEADER", "EVENT_HEADER", "DEFAULT_TOLERANCE", "WebhookEvent", "sign", "sign_v2", "verify",
           "construct_event"]

SIGNATURE_HEADER = "X-SoncoPay-Signature"
SIGNATURE_V2_HEADER = "X-SoncoPay-Signature-V2"
SIGNATURE_LEGACY_HEADER = "X-SoncoPay-Signature-Legacy"
TIMESTAMP_HEADER = "X-SoncoPay-Timestamp"
DELIVERY_ID_HEADER = "X-SoncoPay-Delivery-Id"
EVENT_HEADER = "X-SoncoPay-Event"
DEFAULT_TOLERANCE = 300  # seconds

RawBody = Union[bytes, bytearray, memoryview, str]
SignatureInput = Union[str, bytes, None, Mapping[str, Any]]


@dataclass(frozen=True)
class WebhookEvent:
    """A verified webhook. ``data`` is a payment, payout or refund object (``late`` added on payment.paid,
    ``settlement`` on payment.paid and payment.settled, ``refunded_amount`` and ``refund`` on payment.refunded)."""

    event: str
    created_at: Optional[str]
    data: Dict[str, Any] = field(default_factory=dict)

    @property
    def type(self) -> str:
        return self.event


def _raw(payload: RawBody) -> bytes:
    if isinstance(payload, (bytes, bytearray, memoryview)):
        return bytes(payload)
    if isinstance(payload, str):
        return payload.encode("utf-8")
    raise TypeError("webhook payload must be the RAW request body (bytes or str), not a parsed object")


def _text(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, (list, tuple)):
        v = v[0] if v else None
    if isinstance(v, bytes):
        v = v.decode("ascii", "replace")
    return str(v) if v else None


def _get(headers: Mapping[str, Any], name: str) -> Optional[str]:
    wsgi = "HTTP_" + name.upper().replace("-", "_")
    getter = getattr(headers, "get", None)
    if getter is not None:
        for n in (name, name.lower(), wsgi):
            v = _text(getter(n))
            if v:
                return v
    try:
        for k, v in headers.items():  # type: ignore[union-attr]
            k2 = str(k).lower().replace("_", "-")
            if k2 in (name.lower(), "http-" + name.lower()) and v:
                return _text(v)
    except AttributeError:
        pass
    return None


def _candidates(signature: SignatureInput) -> List[str]:
    """Signatures to check, timestamped first."""
    if signature is None:
        return []
    if isinstance(signature, (str, bytes)):
        v = _text(signature)
        return [v] if v else []
    out = [v for v in (_get(signature, SIGNATURE_V2_HEADER), _get(signature, SIGNATURE_HEADER)) if v]
    return sorted(out, key=lambda s: 0 if s.strip().startswith("t=") else 1)


def sign(payload: RawBody, secret: str) -> str:
    """Legacy signature: hex HMAC-SHA512 of the raw body."""
    if not secret:
        raise ValueError("webhook secret is required")
    return hmac.new(secret.encode("utf-8"), _raw(payload), hashlib.sha512).hexdigest()


def sign_v2(payload: RawBody, secret: str, timestamp: Optional[int] = None) -> str:
    """Timestamped signature ``t=<ts>,v1=<hex HMAC-SHA256(secret, "<ts>." + raw body)>`` (tests, local tools)."""
    if not secret:
        raise ValueError("webhook secret is required")
    ts = int(time.time() if timestamp is None else timestamp)
    mac = hmac.new(secret.encode("utf-8"), f"{ts}.".encode("ascii") + _raw(payload), hashlib.sha256).hexdigest()
    return f"t={ts},v1={mac}"


def _parse_v2(header: str):
    ts, macs = None, []
    for part in header.split(","):
        k, _, v = part.strip().partition("=")
        if k == "t":
            ts = v.strip()
        elif k == "v1" and v:
            macs.append(v.strip().lower())
    try:
        return int(ts), macs  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None, macs


def _check(raw: bytes, signature: SignatureInput, secret: str, tolerance: int, now: Optional[float],
           allow_legacy: bool) -> Optional[str]:
    """None when valid, otherwise the reason."""
    if not secret:
        raise ValueError("webhook secret is required")
    # 2.11.1: an invalid tolerance or now (nan, inf, text, negative) is refused instead of silently disabling the
    # replay protection
    if isinstance(tolerance, bool) or not isinstance(tolerance, (int, float)) or not math.isfinite(tolerance)             or tolerance < 0:
        raise ValueError("webhook tolerance must be a finite number of seconds >= 0")
    if now is not None and (isinstance(now, bool) or not isinstance(now, (int, float)) or not math.isfinite(now)):
        raise ValueError("webhook now must be a finite unix time")
    cands = _candidates(signature)
    if not cands:
        return "missing X-SoncoPay-Signature header"
    first = cands[0].strip()
    if first.startswith("t="):
        ts, macs = _parse_v2(first)
        if ts is None or not macs:
            return "malformed webhook signature"
        if abs((time.time() if now is None else now) - ts) > tolerance:
            return "webhook timestamp is outside the tolerance (possible replay)"
        expected = hmac.new(secret.encode("utf-8"), f"{ts}.".encode("ascii") + raw, hashlib.sha256).hexdigest()
        if any(hmac.compare_digest(m.encode("ascii", "replace"), expected.encode("ascii")) for m in macs):
            return None
        return "webhook signature does not match the payload"
    if not allow_legacy:
        return "legacy webhook signature refused (timestamped signature required)"
    expected = sign(raw, secret)
    if hmac.compare_digest(first.lower().encode("ascii", "replace"), expected.encode("ascii")):
        return None
    return "webhook signature does not match the payload"


def verify(payload: RawBody, signature: SignatureInput, secret: str, *, tolerance: int = DEFAULT_TOLERANCE,
           now: Optional[float] = None, allow_legacy: bool = True) -> bool:
    """True when the signature (header value, or the whole headers mapping) matches the raw body. Constant-time.
    A timestamped signature must be within ``tolerance`` seconds; ``allow_legacy=False`` refuses the old format."""
    return _check(_raw(payload), signature, secret, tolerance, now, allow_legacy) is None


def construct_event(payload: RawBody, signature: SignatureInput, secret: str, *,
                    tolerance: int = DEFAULT_TOLERANCE, now: Optional[float] = None,
                    allow_legacy: bool = True) -> WebhookEvent:
    """Verify the signature then parse the event. Raises SignatureVerificationError."""
    raw = _raw(payload)
    why = _check(raw, signature, secret, tolerance, now, allow_legacy)
    if why is not None:
        raise SignatureVerificationError(why)
    try:
        obj = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise SignatureVerificationError("webhook payload is not valid JSON") from exc
    if not isinstance(obj, dict) or not isinstance(obj.get("event"), str):
        raise SignatureVerificationError("webhook payload has no event type")
    data = obj.get("data")
    return WebhookEvent(event=obj["event"], created_at=obj.get("created_at"), data=data if isinstance(data, dict) else {})
