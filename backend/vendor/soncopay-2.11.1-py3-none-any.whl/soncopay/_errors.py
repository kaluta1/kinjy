"""Exceptions raised by the Sonco Pay SDK."""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Type

__all__ = [
    "SoncoPayError",
    "ApiError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "ApiConnectionError",
    "ApiTimeoutError",
    "SignatureVerificationError",
]


class SoncoPayError(Exception):
    """Base class of every SDK error."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class ApiError(SoncoPayError):
    """The API answered with a non-2xx status.

    ``code`` is the stable code returned by the API when present (``kyb_required``, ``permission_denied``...),
    otherwise it is derived from the HTTP status. Extra fields of the error body are in ``body``.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int,
        code: str,
        detail: Any = None,
        body: Any = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.detail = detail
        self.body = body
        self.headers: Dict[str, str] = dict(headers or {})

    def __str__(self) -> str:
        return f"{self.message} (HTTP {self.status}, {self.code})"

    def __repr__(self) -> str:
        return f"{type(self).__name__}(status={self.status!r}, code={self.code!r}, message={self.message!r})"

    def _extra(self, name: str) -> Optional[str]:
        v = self.body.get(name) if isinstance(self.body, dict) else None
        return v if isinstance(v, str) and v else None

    @property
    def usable_from(self) -> Optional[str]:
        """``usable_from`` of a ``destination_cooling_down`` error (ISO 8601), else None."""
        return self._extra("usable_from")

    @property
    def destination_id(self) -> Optional[str]:
        """``destination_id`` of a ``destination_duplicate`` error (the destination already saved), else None."""
        return self._extra("destination_id")

    @property
    def field(self) -> Optional[str]:
        """Field named by a ``destination_invalid``, ``payer_invalid`` or ``payer_field_unknown`` error, else None."""
        return self._extra("field")

    @property
    def fields(self) -> List[str]:
        """``fields`` of a ``payer_required`` error (payer fields still missing), else []."""
        v = self.body.get("fields") if isinstance(self.body, dict) else None
        return [f for f in v if isinstance(f, str)] if isinstance(v, list) else []


class BadRequestError(ApiError):
    """HTTP 400."""


class AuthenticationError(ApiError):
    """HTTP 401: missing, invalid or revoked API key."""


class PermissionDeniedError(ApiError):
    """HTTP 403: for example a suspended merchant account."""


class NotFoundError(ApiError):
    """HTTP 404."""


class ConflictError(ApiError):
    """HTTP 409: state conflict (payment already paid, order_id reused with another amount...)."""


class ValidationError(ApiError):
    """HTTP 422: the request was refused (field errors, insufficient balance, below minimum...)."""

    @property
    def errors(self) -> List[Dict[str, Any]]:
        """Field errors when the API returned a validation list, else []."""
        return list(self.detail) if isinstance(self.detail, list) else []


class RateLimitError(ApiError):
    """HTTP 429."""


class ServerError(ApiError):
    """HTTP 5xx (502: payment provider error, 503: temporarily unavailable)."""


class ApiConnectionError(SoncoPayError):
    """The request never got an HTTP answer (DNS, refused connection, TLS, reset...)."""


class ApiTimeoutError(ApiConnectionError):
    """No answer within the configured timeout."""


class SignatureVerificationError(SoncoPayError):
    """A webhook signature is missing or does not match the raw body."""


_CODES = {
    400: "bad_request",
    401: "authentication_error",
    403: "permission_denied",
    404: "not_found",
    409: "conflict",
    422: "validation_error",
    429: "rate_limited",
    502: "provider_error",
    503: "service_unavailable",
}

_CLASSES: Dict[int, Type[ApiError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
}


def _detail_message(detail: Any) -> Optional[str]:
    if isinstance(detail, str):
        return detail
    if isinstance(detail, list):
        parts = []
        for e in detail:
            if isinstance(e, dict):
                loc = ".".join(str(p) for p in (e.get("loc") or []) if p != "body")
                parts.append(f"{loc}: {e.get('msg')}" if loc else str(e.get("msg")))
            else:
                parts.append(str(e))
        return "; ".join(parts)
    return None


def make_api_error(status: int, body: Any, headers: Optional[Mapping[str, str]] = None) -> ApiError:
    detail = body.get("detail") if isinstance(body, dict) else None
    code = body.get("code") if isinstance(body, dict) and isinstance(body.get("code"), str) else None
    code = code or _CODES.get(status) or ("server_error" if status >= 500 else "api_error")
    message = _detail_message(detail)
    if not message:
        if isinstance(body, str) and body and len(body) < 300 and not body.lstrip().startswith("<"):
            message = body
        else:
            message = f"HTTP {status}"
    cls = _CLASSES.get(status) or (ServerError if status >= 500 else ApiError)
    return cls(message, status=status, code=code, detail=detail, body=body, headers=headers)
