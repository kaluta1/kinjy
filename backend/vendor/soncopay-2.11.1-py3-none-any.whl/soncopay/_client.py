"""HTTP client for the Sonco Pay merchant API (standard library only)."""
from __future__ import annotations

import http.client
import json
import os
import random
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from decimal import Decimal
from typing import Any, Callable, Dict, Iterator, List, Mapping, Optional, Union

from . import webhooks as _webhooks
from ._errors import ApiConnectionError, ApiTimeoutError, make_api_error
from ._version import __version__

__all__ = ["SoncoPay", "DEFAULT_BASE_URL"]

DESTINATION_KINDS = ("crypto", "mobile_money", "bank")
#: Statuses after which the payer has nothing left to do (``payments.poll``).
FINAL_STATUSES = ("paid", "expired", "failed", "partially_paid")
PAYER_FIELDS = ("name", "email", "phone", "country", "reference")

#: Default API host. Change it here (or pass ``base_url``) once the production domain is known.
DEFAULT_BASE_URL = "https://soncopay.example"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
_RETRY_STATUSES = (429, 502, 503, 504)
#: A 503 (maintenance, payments or payouts closed, provider blocked) is retried at most once, GET only.
MAX_503_RETRIES = 1

Amount = Union[str, int, float, Decimal]
JSON = Dict[str, Any]


def _amount(value: Amount) -> str:
    """Amounts travel as decimal strings so no precision is lost."""
    if isinstance(value, bool):
        raise TypeError("amount must be a number or a decimal string")
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("amount must be finite")
        return format(value, "f")
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("amount must be finite")
        return repr(value)
    return str(value)


def _clean(d: Mapping[str, Any]) -> JSON:
    return {k: v for k, v in d.items() if v is not None}


def _payer(payer: Optional[Mapping[str, Any]]) -> Optional[JSON]:
    """Payer information: ``None`` fields are dropped (the API ignores them anyway)."""
    if payer is None:
        return None
    if not isinstance(payer, Mapping):
        raise TypeError("payer must be a mapping (" + ", ".join(PAYER_FIELDS) + ")")
    return _clean(payer)


def _path_id(value: str, what: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{what} id must be a non-empty string")
    return urllib.parse.quote(value, safe="")


class _Resource:
    def __init__(self, client: "SoncoPay") -> None:
        self._client = client


class Payments(_Resource):
    """``/v1/payments``"""

    def create(
        self,
        *,
        amount: Amount,
        currency: str,
        order_id: Optional[str] = None,
        description: Optional[str] = None,
        customer_email: Optional[str] = None,
        return_url: Optional[str] = None,
        callback_url: Optional[str] = None,
        lifetime_minutes: Optional[int] = None,
        methods: Optional[List[str]] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        country: Optional[str] = None,
        method: Optional[str] = None,
        phone: Optional[str] = None,
        operator: Optional[str] = None,
        payer: Optional[Mapping[str, Any]] = None,
        fee_paid_by: Optional[str] = None,
        asset: Optional[str] = None,
        network: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """Create a payment. Sending the same ``order_id`` again returns the same payment (idempotent).

        ``country`` (ISO alpha-2) restricts the offered methods. ``method`` starts the payment right away, without
        redirection: ``"crypto"`` (with ``asset`` and ``network``), ``"binance_pay"``, ``"card"`` or a mobile money
        code such as ``"mtn_bj"`` with ``phone`` (and ``operator`` when the method needs one); the payment then
        carries ``next_action``.
        ``methods`` accepts ``binance_pay``, ``crypto``, ``USDT``, ``USDT:TRON``, ``mobile_money`` or method codes.
        ``payer`` (all optional): ``{"name", "email", "phone", "country", "reference"}``. Fields your account
        requires and you do not send are asked on the payment page (``payer_required`` when ``method`` starts the
        payment at once).
        ``fee_paid_by``: ``"payer"`` (the customer pays the amount plus the fee, you receive the full amount) or
        ``"merchant"`` (the fee is deducted from what you receive); omitted, your account setting applies. A locked
        setting raises ``PermissionDeniedError`` (``fee_bearer_locked``). The payment carries ``fee_paid_by``,
        ``amount_due`` and ``fee_quote``.
        """
        body = _clean({
            "amount": _amount(amount), "currency": currency, "order_id": order_id, "description": description,
            "customer_email": customer_email, "return_url": return_url, "callback_url": callback_url,
            "lifetime_minutes": lifetime_minutes, "methods": methods,
            "metadata": dict(metadata) if metadata is not None else None,
            "country": country, "method": method, "phone": phone, "operator": operator, "payer": _payer(payer),
            "fee_paid_by": fee_paid_by, "asset": asset, "network": network,
        })
        return self._client.request("POST", "/v1/payments", body=body, timeout=timeout)

    def retrieve(self, payment_id: str, *, timeout: Optional[float] = None) -> JSON:
        """The payment, with ``settlement`` (mode and state of the automatic settlement of this payment)."""
        return self._client.request("GET", f"/v1/payments/{_path_id(payment_id, 'payment')}", timeout=timeout)

    def list(
        self,
        *,
        status: Optional[str] = None,
        q: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """``{"items": [...], "has_more": bool}``. ``q`` searches payment id, order id and customer email."""
        query = {"status": status, "q": q, "limit": limit, "offset": offset}
        return self._client.request("GET", "/v1/payments", query=query, timeout=timeout)

    def list_all(self, *, status: Optional[str] = None, q: Optional[str] = None, limit: int = 100,
                 offset: int = 0) -> Iterator[JSON]:
        """Iterate over every matching payment, following ``has_more``."""
        while True:
            page = self.list(status=status, q=q, limit=limit, offset=offset)
            items = page.get("items") or []
            yield from items
            if not page.get("has_more") or not items:
                return
            offset += len(items)

    def methods(self, payment_id: str, *, timeout: Optional[float] = None) -> JSON:
        """``GET /v1/payments/{id}/methods`` (your own payment page, no redirection): the methods offered for THIS
        payment, each with ``service_fee``, ``estimated_pay_amount`` in ``pay_currency``, ``fields`` to ask the payer,
        ``redirect`` and ``choose`` (the arguments of :meth:`choose_method`), plus ``payer_requirements``
        (``fields``, ``missing``)."""
        return self._client.request("GET", f"/v1/payments/{_path_id(payment_id, 'payment')}/methods", timeout=timeout)

    def choose_method(
        self,
        payment_id: str,
        method: str,
        *,
        asset: Optional[str] = None,
        network: Optional[str] = None,
        code: Optional[str] = None,
        phone: Optional[str] = None,
        operator: Optional[str] = None,
        payer: Optional[Mapping[str, Any]] = None,
        return_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """Choice of the payment method on your own page (no redirection). The payment carries ``next_action``.

        * ``"crypto"`` with ``asset`` and ``network``;
        * ``"binance_pay"``;
        * ``"card"`` (bank card, where available: ``next_action`` sends the payer to the secure card page);
        * ``"mobile_money"`` with ``code`` (``"mtn_bj"``...), ``phone`` and, if needed, ``operator``;
        * or directly a mobile money code: ``choose_method(id, "mtn_bj", phone="+22997000000")``.

        ``payer``: information collected on your side, merged with what the payment already has.
        ``return_url``: after a secure page (card, operator page), the payer comes straight back to this URL.
        Call it again to change the method, or to send a new request after a declined one.
        """
        body = _clean({"method": method, "asset": asset, "network": network, "code": code, "phone": phone,
                       "operator": operator, "payer": _payer(payer), "return_url": return_url})
        return self._client.request("POST", f"/v1/payments/{_path_id(payment_id, 'payment')}/method",
                                    body=body, timeout=timeout)

    def choose_crypto(self, payment_id: str, asset: str, network: str, *, payer: Optional[Mapping[str, Any]] = None,
                      timeout: Optional[float] = None) -> JSON:
        """Crypto on a network: ``next_action.type`` is ``"send_crypto"`` (address, amount, network, QR content)."""
        if not asset or not network:
            raise ValueError("asset and network are required")
        return self.choose_method(payment_id, "crypto", asset=asset, network=network, payer=payer, timeout=timeout)

    def choose_mobile_money(self, payment_id: str, code: str, *, phone: Optional[str] = None,
                            operator: Optional[str] = None, payer: Optional[Mapping[str, Any]] = None,
                            return_url: Optional[str] = None, timeout: Optional[float] = None) -> JSON:
        """Mobile money: ``next_action.type`` is ``"approve_on_phone"`` (push) or ``"redirect"`` (operator page)."""
        if not code:
            raise ValueError('code is required (for example "mtn_bj")')
        return self.choose_method(payment_id, "mobile_money", code=code, phone=phone, operator=operator, payer=payer,
                                  return_url=return_url, timeout=timeout)

    def choose_card(self, payment_id: str, *, code: Optional[str] = None, payer: Optional[Mapping[str, Any]] = None,
                    return_url: Optional[str] = None, timeout: Optional[float] = None) -> JSON:
        """Bank card, where available: ``next_action.type`` is ``"redirect"`` (secure card page)."""
        return self.choose_method(payment_id, "card", code=code, payer=payer, return_url=return_url, timeout=timeout)

    def choose_binance_pay(self, payment_id: str, *, payer: Optional[Mapping[str, Any]] = None,
                           timeout: Optional[float] = None) -> JSON:
        """Binance Pay: ``next_action.type`` is ``"open_wallet"`` (link and QR content)."""
        return self.choose_method(payment_id, "binance_pay", payer=payer, timeout=timeout)

    def poll(self, payment_id: str, *, interval: float = 3.0, timeout: float = 600.0,
             until: Optional[Callable[[JSON], bool]] = None) -> JSON:
        """Read the payment every ``interval`` seconds until ``until(payment)`` is true (default: the status or
        ``next_action.type`` changed, or the payment is final) or ``timeout`` seconds have passed; returns the last
        payment read. Each read also refreshes a pending mobile money or card request on our side."""
        deadline = time.monotonic() + timeout
        first = self.retrieve(payment_id)

        def kind(p: JSON) -> tuple:
            return p.get("status"), (p.get("next_action") or {}).get("type")

        stop = until or (lambda p: p.get("status") in FINAL_STATUSES or kind(p) != kind(first))
        p = first
        while not stop(p) and time.monotonic() < deadline:
            time.sleep(max(0.0, min(interval, deadline - time.monotonic())))
            p = self.retrieve(payment_id)
        return p

    def simulate(self, payment_id: str, *, timeout: Optional[float] = None) -> JSON:
        """Test mode only, once a method is chosen: marks the payment as paid with its exact amount."""
        return self._client.request("POST", f"/v1/payments/{_path_id(payment_id, 'payment')}/simulate",
                                    timeout=timeout)

    def timeline(self, payment_id: str, *, timeout: Optional[float] = None) -> JSON:
        """``GET /v1/payments/{id}/timeline``: ``{"object": "timeline", "subject", "livemode", "trace_id", "events"}``.

        Steps of the payment (created, method chosen, waiting for the customer, confirming, paid, notifications).
        """
        return self._client.request("GET", f"/v1/payments/{_path_id(payment_id, 'payment')}/timeline", timeout=timeout)

    def refund_options(self, payment_id: str, *, timeout: Optional[float] = None) -> JSON:
        """``GET /v1/payments/{id}/refund-options`` (2.7.0): ``enabled``, ``disabled_reason``, ``refundable_amount``,
        ``refunded_amount``, ``pending_amount``, ``window_ends_at``, ``fee_grid`` and ``options`` (each destination
        the payer can receive on, with ``conversion``, ``fee_percent`` and ``network_fee``)."""
        return self._client.request("GET", f"/v1/payments/{_path_id(payment_id, 'payment')}/refund-options",
                                    timeout=timeout)

    def qr_code_url(self, payment_id: str) -> str:
        """Public URL of the payment QR code (SVG)."""
        return f"{self._client.base_url}/pay/{_path_id(payment_id, 'payment')}/qr.svg"


class Payouts(_Resource):
    """``/v1/payouts``"""

    def create(
        self,
        *,
        amount: Amount,
        asset: Optional[str] = None,
        network: Optional[str] = None,
        address: Optional[str] = None,
        method: Optional[str] = None,
        phone: Optional[str] = None,
        operator: Optional[str] = None,
        memo: Optional[str] = None,
        reference: Optional[str] = None,
        destination_id: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """Withdraw from your balance. Sending the same ``reference`` again returns the same payout.

        Saved destination: ``destination_id`` (its details replace asset, network, address, method and phone;
        ``asset``, when given, must equal the destination currency). Crypto: ``asset``, ``network`` and
        ``address``. Mobile money: ``method`` (code such as ``"mtn_bj"``), ``phone``, optional ``operator`` and
        ``asset`` (the currency, defaults to the method currency).
        """
        if destination_id is not None:
            if not isinstance(destination_id, str) or not destination_id.strip():
                raise ValueError("destination_id must be a non-empty string")
        elif not method or method == "crypto":
            if not (asset and network and address):
                raise ValueError("destination_id, or asset, network and address, are required for a crypto payout")
        elif not (phone or address):
            raise ValueError("phone is required for a mobile money payout")
        body = _clean({"destination_id": destination_id, "asset": asset, "network": network,
                       "amount": _amount(amount), "address": address, "method": method, "phone": phone,
                       "operator": operator, "memo": memo, "reference": reference})
        return self._client.request("POST", "/v1/payouts", body=body, timeout=timeout)

    def retrieve(self, payout_id: str, *, timeout: Optional[float] = None) -> JSON:
        """The payout. 2.10.0: ``funded_by`` lists what funds it (``source`` ``"other"`` or ``"payment"``,
        ``payment_id``, ``amount``, ``released``); a payment listed there can no longer be refunded."""
        return self._client.request("GET", f"/v1/payouts/{_path_id(payout_id, 'payout')}", timeout=timeout)

    def list(self, *, status: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
             timeout: Optional[float] = None) -> JSON:
        """``{"items": [...]}``"""
        return self._client.request("GET", "/v1/payouts", query={"status": status, "limit": limit, "offset": offset},
                                    timeout=timeout)

    def list_all(self, *, status: Optional[str] = None, limit: int = 100, offset: int = 0) -> Iterator[JSON]:
        while True:
            items = self.list(status=status, limit=limit, offset=offset).get("items") or []
            yield from items
            if len(items) < limit:
                return
            offset += len(items)

    def timeline(self, payout_id: str, *, timeout: Optional[float] = None) -> JSON:
        """``GET /v1/payouts/{id}/timeline``: steps of the payout (requested, review, sent, completed or failed and
        amount returned to the balance)."""
        return self._client.request("GET", f"/v1/payouts/{_path_id(payout_id, 'payout')}/timeline", timeout=timeout)

    def fees(self, *, timeout: Optional[float] = None) -> JSON:
        """``{"fees": {"USDT:TRON": "1", "XOF:mtn_bj": "50", ...}, "fees_percent": {"XOF:mtn_bj": "1"},
        "min_payout_usd": ..., "limits": {...}}``. 2.11.0: mobile money fee of a payout = fixed (``fees``) + amount ×
        ``fees_percent`` / 100, rounded up to the unit of the currency, added to the amount."""
        return self._client.request("GET", "/v1/payout-fees", timeout=timeout)


class PayoutDestinations(_Resource):
    """``/v1/payout-destinations``: saved payout destinations (crypto, mobile money, bank).

    A new destination is ``pending_confirmation``: confirm it in the dashboard (your password is asked again)
    before use. An API key can never confirm a destination. In live mode it becomes usable at ``usable_from``
    (end of the waiting period after confirmation).
    """

    def list(self, *, kind: Optional[str] = None, status: Optional[str] = None,
             timeout: Optional[float] = None) -> JSON:
        """``{"items": [...], "settings": {...}}``; ``kind``: crypto, mobile_money or bank; ``status``:
        pending_confirmation, active, disabled or rejected."""
        return self._client.request("GET", "/v1/payout-destinations", query={"kind": kind, "status": status},
                                    timeout=timeout)

    def create(
        self,
        *,
        kind: str,
        label: Optional[str] = None,
        asset: Optional[str] = None,
        network: Optional[str] = None,
        address: Optional[str] = None,
        memo: Optional[str] = None,
        method: Optional[str] = None,
        phone: Optional[str] = None,
        operator: Optional[str] = None,
        holder: Optional[str] = None,
        bank_name: Optional[str] = None,
        iban: Optional[str] = None,
        account_number: Optional[str] = None,
        swift_bic: Optional[str] = None,
        country: Optional[str] = None,
        currency: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """Save a destination (status ``pending_confirmation``).

        * crypto: ``asset``, ``network``, ``address``, optional ``memo``;
        * mobile_money: ``method`` (code such as ``"mtn_bj"``), ``phone``, optional ``operator`` and ``currency``;
        * bank: ``holder``, ``bank_name``, ``iban`` or ``account_number``, optional ``swift_bic`` and ``country``,
          and ``currency``.
        """
        if kind not in DESTINATION_KINDS:
            raise ValueError("kind must be crypto, mobile_money or bank")
        body = _clean({"kind": kind, "label": label, "asset": asset, "network": network, "address": address,
                       "memo": memo, "method": method, "phone": phone, "operator": operator, "holder": holder,
                       "bank_name": bank_name, "iban": iban, "account_number": account_number,
                       "swift_bic": swift_bic, "country": country, "currency": currency})
        return self._client.request("POST", "/v1/payout-destinations", body=body, timeout=timeout)

    def retrieve(self, destination_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/payout-destinations/{_path_id(destination_id, 'destination')}",
                                    timeout=timeout)

    def update(self, destination_id: str, *, label: Optional[str], timeout: Optional[float] = None) -> JSON:
        """Only the label can change (``None`` removes it); new details = a new destination to confirm."""
        return self._client.request("PATCH", f"/v1/payout-destinations/{_path_id(destination_id, 'destination')}",
                                    body={"label": label}, timeout=timeout)

    def disable(self, destination_id: str, *, timeout: Optional[float] = None) -> JSON:
        """``DELETE``: the destination is disabled (kept, never erased)."""
        return self._client.request("DELETE", f"/v1/payout-destinations/{_path_id(destination_id, 'destination')}",
                                    timeout=timeout)


class Statements(_Resource):
    """``/v1/statements``: account statement (opening balance, lines with the balance after each, closing)."""

    def list(
        self,
        *,
        currency: Optional[str] = None,
        from_: Optional[str] = None,
        to: Optional[str] = None,
        cursor: Optional[int] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """``{"livemode", "currency", "from", "to", "currencies", "opening", "closing", "lines", "next_cursor"}``.

        ``from_`` / ``to``: ``YYYY-MM-DD`` (``to`` inclusive) or ISO 8601. ``limit``: 1 to 1000 (default 200).
        """
        query = {"currency": currency, "from": from_, "to": to, "cursor": cursor, "limit": limit}
        return self._client.request("GET", "/v1/statements", query=query, timeout=timeout)

    def list_all(self, *, currency: Optional[str] = None, from_: Optional[str] = None, to: Optional[str] = None,
                 limit: int = 200) -> Iterator[JSON]:
        """Iterate over every line of the period, following ``next_cursor``."""
        cursor: Optional[int] = None
        while True:
            page = self.list(currency=currency, from_=from_, to=to, cursor=cursor, limit=limit)
            lines = page.get("lines") or []
            yield from lines
            cursor = page.get("next_cursor")
            if not cursor or not lines:
                return

    def csv(self, *, currency: Optional[str] = None, from_: Optional[str] = None, to: Optional[str] = None,
            timeout: Optional[float] = None) -> str:
        """``GET /v1/statements.csv``: CSV text of the whole period (date, currency, type, label, description,
        amount, balance_after, operation_type, operation_id, line_id)."""
        return self._client.request("GET", "/v1/statements.csv", query={"currency": currency, "from": from_, "to": to},
                                    timeout=timeout, raw=True, headers={"Accept": "text/csv"})


class Settlement(_Resource):
    """``/v1/settlement``: automatic settlement of paid amounts.

    ``mode`` is ``"custody"`` (paid amounts stay in your balance) or ``"auto"`` (they are paid out to the
    destination of their route). The mode is chosen in the dashboard (Settings), never with an API key.
    """

    def retrieve(self, *, timeout: Optional[float] = None) -> JSON:
        """``{"mode", "livemode", "routes", "attention", "daily_cap_usd", "used_today_usd", "batch_mode", "items"}``"""
        return self._client.request("GET", "/v1/settlement", timeout=timeout)

    def items(self, *, status: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
              timeout: Optional[float] = None) -> JSON:
        """``{"items": [...], "has_more": bool}``; ``status``: pending, held, settled, failed or cancelled;
        ``limit``: 1 to 200 (default 50)."""
        return self._client.request("GET", "/v1/settlement/items",
                                    query={"status": status, "limit": limit, "offset": offset}, timeout=timeout)

    def set_route(self, *, scope: str, destination_id: Optional[str], timeout: Optional[float] = None) -> JSON:
        """``PUT /v1/settlement/routes``: returns the updated summary (as :meth:`retrieve`).

        ``scope``: an asset (``"USDT"``), an asset on a network (``"USDT:TRON"``) or a currency (``"XOF"``).
        ``destination_id``: a saved payout destination receiving that currency, or ``None`` to remove the route.
        """
        if not isinstance(scope, str) or not scope.strip():
            raise ValueError("scope must be a non-empty string")
        if destination_id is not None and (not isinstance(destination_id, str) or not destination_id.strip()):
            raise ValueError("destination_id must be a non-empty string, or None to remove the route")
        return self._client.request("PUT", "/v1/settlement/routes",
                                    body={"scope": scope, "destination_id": destination_id}, timeout=timeout)


class Ledger(_Resource):
    """``/v1/ledger``"""

    def list(self, *, asset: Optional[str] = None, limit: Optional[int] = None, offset: Optional[int] = None,
             timeout: Optional[float] = None) -> JSON:
        """``{"items": [...]}``: every balance movement (payment, fee, payout, payout_fee, payout_release).

        Once the platform keeps its books in double entry, ``id`` becomes the id of the accounting line: do not
        compare ids across that switch. Prefer :class:`Statements` for reconciliation.
        """
        return self._client.request("GET", "/v1/ledger", query={"asset": asset, "limit": limit, "offset": offset},
                                    timeout=timeout)

    def list_all(self, *, asset: Optional[str] = None, limit: int = 100, offset: int = 0) -> Iterator[JSON]:
        while True:
            items = self.list(asset=asset, limit=limit, offset=offset).get("items") or []
            yield from items
            if len(items) < limit:
                return
            offset += len(items)


# ---------------------------------------------------------------- 2.2.0 : facturation


def _idem(key: Optional[str]) -> Optional[Dict[str, str]]:
    return {"Idempotency-Key": str(key)} if key else None


def _body(params: Mapping[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in params.items() if v is not None}


class Customers(_Resource):
    """``/v1/customers``: the people and businesses you bill (name, email, phone in E.164, country, locale,
    timezone, external_ref, metadata, consent ``{"email", "sms", "whatsapp"}``)."""

    def create(self, *, name: str, idempotency_key: Optional[str] = None, timeout: Optional[float] = None,
               **fields: Any) -> JSON:
        return self._client.request("POST", "/v1/customers", body=_body({"name": name, **fields}), timeout=timeout,
                                    headers=_idem(idempotency_key))

    def list(self, *, q: Optional[str] = None, archived: Optional[bool] = None, limit: Optional[int] = None,
             offset: Optional[int] = None, timeout: Optional[float] = None) -> JSON:
        """``{"items", "has_more", "next_offset"}``"""
        return self._client.request("GET", "/v1/customers", query={"q": q, "archived": archived, "limit": limit,
                                                                   "offset": offset}, timeout=timeout)

    def retrieve(self, customer_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/customers/{_path_id(customer_id, 'customer')}", timeout=timeout)

    def update(self, customer_id: str, *, timeout: Optional[float] = None, **fields: Any) -> JSON:
        return self._client.request("PATCH", f"/v1/customers/{_path_id(customer_id, 'customer')}", body=fields,
                                    timeout=timeout)

    def archive(self, customer_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("DELETE", f"/v1/customers/{_path_id(customer_id, 'customer')}", timeout=timeout)


class Plans(_Resource):
    """``/v1/plans``: reusable offers (amount, currency, interval week|month|quarter|year|custom, trial_days)."""

    def create(self, *, name: str, amount: Any, currency: str, interval: str = "month",
               idempotency_key: Optional[str] = None, timeout: Optional[float] = None, **fields: Any) -> JSON:
        body = _body({"name": name, "amount": str(amount), "currency": currency, "interval": interval, **fields})
        return self._client.request("POST", "/v1/plans", body=body, timeout=timeout, headers=_idem(idempotency_key))

    def list(self, *, active: Optional[bool] = None, limit: Optional[int] = None, offset: Optional[int] = None,
             timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", "/v1/plans", query={"active": active, "limit": limit, "offset": offset},
                                    timeout=timeout)

    def retrieve(self, plan_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/plans/{_path_id(plan_id, 'plan')}", timeout=timeout)

    def update(self, plan_id: str, *, timeout: Optional[float] = None, **fields: Any) -> JSON:
        return self._client.request("PATCH", f"/v1/plans/{_path_id(plan_id, 'plan')}", body=fields, timeout=timeout)


class Invoices(_Resource):
    """``/v1/invoices``: draft, issue (sequential number), send, remind, void; the customer pays the
    ``hosted_url`` page with every active method. Webhooks ``invoice.*``."""

    def create(self, *, currency: str, lines: List[Mapping[str, Any]], customer_id: Optional[str] = None,
               customer: Optional[Mapping[str, Any]] = None, idempotency_key: Optional[str] = None,
               timeout: Optional[float] = None, **fields: Any) -> JSON:
        """``fields``: due_date, due_days, notes, footer, memo, allow_partial, min_partial, reminders,
        external_ref, metadata, issue, send, channels."""
        body = _body({"customer_id": customer_id, "customer": customer, "currency": currency,
                      "lines": [dict(x) for x in lines], **fields})
        return self._client.request("POST", "/v1/invoices", body=body, timeout=timeout, headers=_idem(idempotency_key))

    def list(self, *, status: Optional[str] = None, customer_id: Optional[str] = None,
             subscription_id: Optional[str] = None, q: Optional[str] = None, limit: Optional[int] = None,
             offset: Optional[int] = None, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", "/v1/invoices", query={
            "status": status, "customer_id": customer_id, "subscription_id": subscription_id, "q": q, "limit": limit,
            "offset": offset}, timeout=timeout)

    def retrieve(self, invoice_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/invoices/{_path_id(invoice_id, 'invoice')}", timeout=timeout)

    def update(self, invoice_id: str, *, timeout: Optional[float] = None, **fields: Any) -> JSON:
        return self._client.request("PATCH", f"/v1/invoices/{_path_id(invoice_id, 'invoice')}", body=fields,
                                    timeout=timeout)

    def delete_draft(self, invoice_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("DELETE", f"/v1/invoices/{_path_id(invoice_id, 'invoice')}", timeout=timeout)

    def _post(self, invoice_id: str, action: str, body: Mapping[str, Any], timeout: Optional[float]) -> JSON:
        return self._client.request("POST", f"/v1/invoices/{_path_id(invoice_id, 'invoice')}/{action}",
                                    body=_body(body), timeout=timeout)

    def issue(self, invoice_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._post(invoice_id, "issue", {}, timeout)

    def send(self, invoice_id: str, *, channels: Optional[List[str]] = None, timeout: Optional[float] = None) -> JSON:
        return self._post(invoice_id, "send", {"channels": channels}, timeout)

    def remind(self, invoice_id: str, *, channels: Optional[List[str]] = None, timeout: Optional[float] = None) -> JSON:
        return self._post(invoice_id, "remind", {"channels": channels}, timeout)

    def void(self, invoice_id: str, *, reason: Optional[str] = None, timeout: Optional[float] = None) -> JSON:
        return self._post(invoice_id, "void", {"reason": reason}, timeout)

    def mark_paid(self, invoice_id: str, *, amount: Any = None, note: Optional[str] = None,
                  timeout: Optional[float] = None) -> JSON:
        return self._post(invoice_id, "mark-paid", {"amount": None if amount is None else str(amount), "note": note},
                          timeout)

    def timeline(self, invoice_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/invoices/{_path_id(invoice_id, 'invoice')}/timeline", timeout=timeout)


class Subscriptions(_Resource):
    """``/v1/subscriptions``: one invoice per due date, reminders before and after, unpaid policy.
    ``auto_debit=True`` fails with ``auto_debit_unavailable`` (automatic card debit is not available yet)."""

    def create(self, *, customer_id: Optional[str] = None, customer: Optional[Mapping[str, Any]] = None,
               idempotency_key: Optional[str] = None, timeout: Optional[float] = None, **fields: Any) -> JSON:
        """``fields``: plan_id, description, amount, currency, tax_rate, interval, interval_days, start_date,
        trial_days, cycles, days_until_due, preferred_method, allow_partial, reminders, dunning, external_ref."""
        if "amount" in fields and fields["amount"] is not None:
            fields["amount"] = str(fields["amount"])
        body = _body({"customer_id": customer_id, "customer": customer, **fields})
        return self._client.request("POST", "/v1/subscriptions", body=body, timeout=timeout,
                                    headers=_idem(idempotency_key))

    def list(self, *, status: Optional[str] = None, customer_id: Optional[str] = None, q: Optional[str] = None,
             limit: Optional[int] = None, offset: Optional[int] = None, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", "/v1/subscriptions", query={"status": status, "customer_id": customer_id,
                                                                       "q": q, "limit": limit, "offset": offset},
                                    timeout=timeout)

    def retrieve(self, subscription_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/subscriptions/{_path_id(subscription_id, 'subscription')}",
                                    timeout=timeout)

    def update(self, subscription_id: str, *, timeout: Optional[float] = None, **fields: Any) -> JSON:
        """amount and description apply from the next invoice."""
        return self._client.request("PATCH", f"/v1/subscriptions/{_path_id(subscription_id, 'subscription')}",
                                    body=fields, timeout=timeout)

    def _post(self, subscription_id: str, action: str, body: Mapping[str, Any], timeout: Optional[float]) -> JSON:
        return self._client.request("POST", f"/v1/subscriptions/{_path_id(subscription_id, 'subscription')}/{action}",
                                    body=_body(body), timeout=timeout)

    def pause(self, subscription_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._post(subscription_id, "pause", {}, timeout)

    def resume(self, subscription_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._post(subscription_id, "resume", {}, timeout)

    def cancel(self, subscription_id: str, *, at_period_end: bool = False, reason: Optional[str] = None,
               void_open_invoices: bool = False, timeout: Optional[float] = None) -> JSON:
        return self._post(subscription_id, "cancel", {"at_period_end": at_period_end, "reason": reason,
                                                      "void_open_invoices": void_open_invoices}, timeout)

    def timeline(self, subscription_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/subscriptions/{_path_id(subscription_id, 'subscription')}/timeline",
                                    timeout=timeout)


class Billing(_Resource):
    """``/v1/billing``: summary (outstanding, overdue, MRR), messages, test clock."""

    def summary(self, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", "/v1/billing/summary", timeout=timeout)

    def messages(self, *, invoice_id: Optional[str] = None, customer_id: Optional[str] = None,
                 channel: Optional[str] = None, status: Optional[str] = None, limit: Optional[int] = None,
                 offset: Optional[int] = None, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", "/v1/billing/messages", query={
            "invoice_id": invoice_id, "customer_id": customer_id, "channel": channel, "status": status,
            "limit": limit, "offset": offset}, timeout=timeout)

    def advance_test_clock(self, *, days: int = 0, hours: int = 0, reset: bool = False,
                           timeout: Optional[float] = None) -> JSON:
        """Test mode only: moves the billing clock forward and processes due dates and reminders at once."""
        return self._client.request("POST", "/v1/billing/test-clock", body={"advance_days": days, "advance_hours": hours,
                                                                            "reset": reset}, timeout=timeout)


# ---------------------------------------------------------------- 2.7.0: refunds and cancellations


def _refund_body(payment_id: str, amount: Optional[Amount], fields: Mapping[str, Any]) -> JSON:
    if not isinstance(payment_id, str) or not payment_id.strip():
        raise ValueError("payment_id is required")
    return _body({"payment_id": payment_id, "amount": None if amount is None else _amount(amount), **fields})


class Refunds(_Resource):
    """``/v1/refunds`` (2.7.0): refunds and cancellations of a payment.

    The refundable amount is the ``net_amount`` of the payment (what you received) minus what is already refunded
    or on its way. A change of method between the payment and the refund has a fee, deducted from the refund; your
    share of it is credited to your balance. :meth:`preview` shows the figures without creating anything.
    """

    def create(
        self,
        *,
        payment_id: str,
        amount: Optional[Amount] = None,
        cancel: Optional[bool] = None,
        mode: Optional[str] = None,
        destination: Optional[Mapping[str, Any]] = None,
        reason: Optional[str] = None,
        reference: Optional[str] = None,
        metadata: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> JSON:
        """``POST /v1/refunds`` (201). ``amount`` omitted: everything still refundable. ``cancel=True`` cancels the
        payment and refunds everything left (``amount`` ignored, kind ``"cancel"``). ``mode``: ``"direct"`` (default,
        ``destination`` required) or ``"link"`` (the payer chooses on ``link_url``). ``destination``:
        ``{"kind": "crypto", "asset", "network", "address", "memo"}``, ``{"kind": "mobile_money", "method",
        "phone"}`` or (2.10.0) ``{"kind": "original"}``: back to the number that paid a mobile money payment. A payment
        whose money was already withdrawn raises ``ConflictError`` ``payment_already_withdrawn``. The same ``reference`` returns the same refund; ``idempotency_key`` is sent as Idempotency-Key.
        """
        body = _refund_body(payment_id, amount, {"cancel": cancel, "mode": mode, "destination": destination,
                                                 "reason": reason, "reference": reference, "metadata": metadata})
        return self._client.request("POST", "/v1/refunds", body=body, timeout=timeout, headers=_idem(idempotency_key))

    def list(self, *, payment_id: Optional[str] = None, status: Optional[str] = None, limit: Optional[int] = None,
             offset: Optional[int] = None, timeout: Optional[float] = None) -> JSON:
        """``{"items": [...], "has_more": bool}``"""
        return self._client.request("GET", "/v1/refunds", query={"payment_id": payment_id, "status": status,
                                                                 "limit": limit, "offset": offset}, timeout=timeout)

    def list_all(self, *, payment_id: Optional[str] = None, status: Optional[str] = None, limit: int = 100,
                 offset: int = 0) -> Iterator[JSON]:
        """Every refund matching the filters, following ``has_more``."""
        while True:
            page = self.list(payment_id=payment_id, status=status, limit=limit, offset=offset)
            items = page.get("items") or []
            yield from items
            if not page.get("has_more") or not items:
                return
            offset += len(items)

    def retrieve(self, refund_id: str, *, timeout: Optional[float] = None) -> JSON:
        return self._client.request("GET", f"/v1/refunds/{_path_id(refund_id, 'refund')}", timeout=timeout)

    def cancel(self, refund_id: str, *, reason: Optional[str] = None, timeout: Optional[float] = None) -> JSON:
        """``POST /v1/refunds/{id}/cancel``: the amount is back in your balance. Only before the refund is sent
        (awaiting_payer, scheduled, pending_review, awaiting_approval), else 409 ``refund_not_cancellable``."""
        return self._client.request("POST", f"/v1/refunds/{_path_id(refund_id, 'refund')}/cancel",
                                    body=_body({"reason": reason}), timeout=timeout)

    def preview(self, *, payment_id: str, amount: Optional[Amount] = None, cancel: Optional[bool] = None,
                destination: Optional[Mapping[str, Any]] = None, timeout: Optional[float] = None) -> JSON:
        """``POST /v1/refunds/preview``: ``refund_preview`` with ``fee_percent``, ``fee``, ``partner_share``,
        ``net_amount``, ``rate``, ``network_fee`` and ``payer_amount`` (what the payer receives). Nothing is
        created."""
        body = _refund_body(payment_id, amount, {"cancel": cancel, "destination": destination})
        return self._client.request("POST", "/v1/refunds/preview", body=body, timeout=timeout)


class SoncoPay:
    """Sonco Pay API client.

    >>> sp = SoncoPay("sp_test_...")                       # or SONCOPAY_API_KEY
    >>> sp = SoncoPay("sp_test_...", base_url="https://...", timeout=20, max_retries=2)
    """

    webhooks = _webhooks

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        key = api_key or os.environ.get("SONCOPAY_API_KEY")
        if not key or not isinstance(key, str):
            raise ValueError("an API key (sp_live_... or sp_test_...) is required")
        if not (key.startswith("sp_live_") or key.startswith("sp_test_")):
            raise ValueError("the API key must start with sp_live_ or sp_test_")
        self.__api_key = key
        self.base_url = (base_url or os.environ.get("SONCOPAY_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = float(timeout)
        self.max_retries = int(max_retries)
        self.user_agent = f"soncopay-python/{__version__}"
        self.payments = Payments(self)
        self.payouts = Payouts(self)
        self.ledger = Ledger(self)
        self.payout_destinations = PayoutDestinations(self)
        self.statements = Statements(self)
        self.settlement = Settlement(self)
        self.customers = Customers(self)
        self.plans = Plans(self)
        self.invoices = Invoices(self)
        self.subscriptions = Subscriptions(self)
        self.billing = Billing(self)
        self.refunds = Refunds(self)

    def __repr__(self) -> str:
        return f"SoncoPay(base_url={self.base_url!r}, test_mode={self.is_test_mode})"

    @property
    def is_test_mode(self) -> bool:
        """True for a sp_test_ key: separate test data, payments can be simulated."""
        return self.__api_key.startswith("sp_test_")

    @property
    def livemode(self) -> bool:
        return not self.is_test_mode

    # ------------------------------------------------------------ top-level routes

    def methods(self, *, timeout: Optional[float] = None) -> JSON:
        """``{"methods": [...], "assets": {...}, "networks": {...}, "payment_methods": [...]}``

        Each entry of ``methods`` has ``method``, ``code``, ``kind``, ``label``, ``asset``, ``network``; mobile
        money entries add ``operator``, ``countries``, ``currency``, ``redirect`` and ``fields``.
        """
        return self.request("GET", "/v1/methods", timeout=timeout)

    def rates(self, *, timeout: Optional[float] = None) -> Dict[str, str]:
        """USD value of one unit of each symbol, as decimal strings: ``{"USDT": "1", "BTC": "...", ...}``"""
        return self.request("GET", "/v1/rates", timeout=timeout)

    def balances(self, *, timeout: Optional[float] = None) -> JSON:
        """``{"livemode": bool, "balances": {"USDT": "12.5", ...}, "reserved": {"USDT": "3", ...}}``

        ``reserved`` = amount + fee of the payouts still open, already deducted from ``balances``.
        2.10.0: ``available`` = what can be withdrawn now, per currency; ``on_hold`` = ``{"USDT": {"amount",
        "next_available_at"}}`` for what is still in its waiting period (a payout above ``available`` raises
        ``ValidationError`` ``payout_funds_on_hold``).
        """
        return self.request("GET", "/v1/balances", timeout=timeout)

    def fees(self, *, timeout: Optional[float] = None) -> JSON:
        """Your effective commission: ``{"livemode", "payment", "per_method", "payout_fees", "limits", "fee_bearer"}``.

        ``fee_bearer``: ``{"fee_bearer": "payer"|"merchant", "source": "merchant"|"platform", "platform_default",
        "locked"}``.
        """
        return self.request("GET", "/v1/fees", timeout=timeout)

    # ------------------------------------------------------------ transport

    def request(
        self,
        method: str,
        path: str,
        *,
        query: Optional[Mapping[str, Any]] = None,
        body: Optional[Mapping[str, Any]] = None,
        timeout: Optional[float] = None,
        headers: Optional[Mapping[str, str]] = None,
        raw: bool = False,
    ) -> Any:
        """Low-level call. GET requests are retried on network errors, 429, 502 and 504, and at most once
        on 503 (maintenance, closed payments or payouts).

        POST requests are never retried automatically: use ``order_id`` / ``reference`` to retry safely.
        ``raw=True`` returns the response body as text (CSV...) instead of decoded JSON.
        """
        method = method.upper()
        url = self.base_url + path
        params = [(k, str(v)) for k, v in (query or {}).items() if v is not None and v != ""]
        if params:
            url += "?" + urllib.parse.urlencode(params)
        h = {"Accept": "application/json"}
        h.update(headers or {})
        h.update({"User-Agent": self.user_agent, "X-Api-Key": self.__api_key})
        data = None
        if body is not None:
            data = json.dumps(body, separators=(",", ":"), default=str).encode("utf-8")
            h["Content-Type"] = "application/json"
        retries = self.max_retries if method == "GET" else 0
        wait = self.timeout if timeout is None else float(timeout)
        attempt = 0
        retries_503 = 0
        while True:
            req = urllib.request.Request(url, data=data, headers=h, method=method)
            try:
                with urllib.request.urlopen(req, timeout=wait) as resp:  # noqa: S310 (URL built from base_url)
                    payload = resp.read()
                    return payload.decode("utf-8", "replace") if raw else _decode(payload)
            except urllib.error.HTTPError as exc:
                err_body = exc.read()
                resp_headers = {k.lower(): v for k, v in (exc.headers.items() if exc.headers else [])}
                exc.close()
                retry_ok = exc.code in _RETRY_STATUSES and (exc.code != 503 or retries_503 < MAX_503_RETRIES)
                if retry_ok and attempt < retries:
                    if exc.code == 503:
                        retries_503 += 1
                    time.sleep(_backoff(attempt, resp_headers.get("retry-after")))
                    attempt += 1
                    continue
                raise make_api_error(exc.code, _decode(err_body), resp_headers) from None
            except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
                if attempt < retries:
                    time.sleep(_backoff(attempt))
                    attempt += 1
                    continue
                reason = getattr(exc, "reason", exc)
                if isinstance(reason, (socket.timeout, TimeoutError)) or isinstance(exc, (socket.timeout, TimeoutError)):
                    raise ApiTimeoutError(f"request timed out after {wait:g} s: {method} {path}") from exc
                raise ApiConnectionError(f"could not reach Sonco Pay ({method} {path}): {reason}") from exc


def _decode(raw: bytes) -> Any:
    if not raw:
        return None
    text = raw.decode("utf-8", "replace")
    try:
        return json.loads(text)
    except ValueError:
        return text


def _backoff(attempt: int, retry_after: Optional[str] = None) -> float:
    try:
        ra = float(retry_after) if retry_after else 0.0
    except ValueError:
        ra = 0.0
    if ra > 0:
        return min(ra, 10.0)
    return min(0.5 * 2 ** attempt, 5.0) + random.random() / 10
